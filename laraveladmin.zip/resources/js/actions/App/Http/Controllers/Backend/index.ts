import SettingsController from './SettingsController'
const Backend = {
    SettingsController: Object.assign(SettingsController, SettingsController),
}

export default Backend