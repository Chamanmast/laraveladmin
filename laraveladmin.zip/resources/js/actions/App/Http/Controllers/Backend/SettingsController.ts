import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Backend\SettingsController::index
 * @see app/Http/Controllers/Backend/SettingsController.php:12
 * @route '/settings/settings'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/settings/settings',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Backend\SettingsController::index
 * @see app/Http/Controllers/Backend/SettingsController.php:12
 * @route '/settings/settings'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Backend\SettingsController::index
 * @see app/Http/Controllers/Backend/SettingsController.php:12
 * @route '/settings/settings'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Backend\SettingsController::index
 * @see app/Http/Controllers/Backend/SettingsController.php:12
 * @route '/settings/settings'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Backend\SettingsController::index
 * @see app/Http/Controllers/Backend/SettingsController.php:12
 * @route '/settings/settings'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Backend\SettingsController::index
 * @see app/Http/Controllers/Backend/SettingsController.php:12
 * @route '/settings/settings'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Backend\SettingsController::index
 * @see app/Http/Controllers/Backend/SettingsController.php:12
 * @route '/settings/settings'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Backend\SettingsController::update
 * @see app/Http/Controllers/Backend/SettingsController.php:19
 * @route '/settings/settings'
 */
export const update = (options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(options),
    method: 'patch',
})

update.definition = {
    methods: ["patch"],
    url: '/settings/settings',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\Backend\SettingsController::update
 * @see app/Http/Controllers/Backend/SettingsController.php:19
 * @route '/settings/settings'
 */
update.url = (options?: RouteQueryOptions) => {
    return update.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Backend\SettingsController::update
 * @see app/Http/Controllers/Backend/SettingsController.php:19
 * @route '/settings/settings'
 */
update.patch = (options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\Backend\SettingsController::update
 * @see app/Http/Controllers/Backend/SettingsController.php:19
 * @route '/settings/settings'
 */
    const updateForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url({
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Backend\SettingsController::update
 * @see app/Http/Controllers/Backend/SettingsController.php:19
 * @route '/settings/settings'
 */
        updateForm.patch = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
const SettingsController = { index, update }

export default SettingsController