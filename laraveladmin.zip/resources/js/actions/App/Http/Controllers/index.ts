import Auth from './Auth'
import Backend from './Backend'
import Settings from './Settings'
const Controllers = {
    Auth: Object.assign(Auth, Auth),
Backend: Object.assign(Backend, Backend),
Settings: Object.assign(Settings, Settings),
}

export default Controllers