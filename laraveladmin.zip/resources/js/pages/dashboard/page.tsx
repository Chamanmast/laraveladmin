
import { ChartAreaInteractive } from "@/components/chart-area-interactive"
import { DataTable } from "@/components/data-table"
import { SectionCards } from "@/components/section-cards"
import { type BreadcrumbItem } from '@/types';
import { edit } from '@/routes/profile';

const breadcrumbs: BreadcrumbItem[] = [
    {
        title: 'Dashboard',
        href: edit().url,
    },
];
import data from "./data.json"
import AppLayout from "@/layouts/app-layout";
import { Head } from "@inertiajs/react";

export default function Page() {
  return (
    <AppLayout breadcrumbs={breadcrumbs}>
            <Head title="Dashboard" />
        <div className="flex flex-1 flex-col">
          <div className="@container/main flex flex-1 flex-col gap-2">
            <div className="flex flex-col gap-4 py-4 md:gap-6 md:py-6">
              <SectionCards />
              <div className="px-4 lg:px-6">
                <ChartAreaInteractive />
              </div>
              <DataTable data={data} />
            </div>
          </div>
        </div>
      </AppLayout>
  )
}
